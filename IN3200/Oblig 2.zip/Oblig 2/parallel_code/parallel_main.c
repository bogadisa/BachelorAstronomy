#include "functions.h"  

#ifdef __MACH__
#include <stdlib.h>
#else 
#include <malloc.h>
#endif

void import_JPEG_file (const char* filename, unsigned char** image_chars,
                       int* image_height, int* image_width,
                       int* num_components);
void export_JPEG_file (const char* filename, const unsigned char* image_chars,
                       int image_height, int image_width,
                       int num_components, int quality);


int main(int argc, char *argv[]) {
    int m, n, c, iters;
    int my_m, my_n, my_rank, num_procs;
    float kappa;
    image u, u_bar, whole_image;
    unsigned char *image_chars, *my_image_chars;
    char *input_jpeg_filename, *output_jpeg_filename;

    MPI_Init (&argc, &argv);
    MPI_Comm_rank (MPI_COMM_WORLD, &my_rank);
    MPI_Comm_size (MPI_COMM_WORLD, &num_procs);

    kappa = strtof(argv[1], NULL) ; iters = atoi(argv[2]) ; input_jpeg_filename = argv[3] ; output_jpeg_filename = argv[4];

    if (my_rank==0) {
        import_JPEG_file(input_jpeg_filename, &image_chars, &m, &n, &c);
        printf("Succeeded! vertical pixels: %d, horizontal pixels: %d, num components: %d\n", m, n, c);
        printf("Allocating images...\n");
        allocate_image (&whole_image, m, n);
    }
    MPI_Bcast (&m, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast (&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
    /* 2D decomposition of the m x n pixels evenly among the MPI processes */
    my_m = m/num_procs + (my_rank < m%num_procs);
    my_n = n;

    allocate_image (&u, my_m, my_n);
    allocate_image (&u_bar, my_m, my_n);
    /* each process asks process 0 for a partitioned region */
    /* of image_chars and copy the values into u */
    /* ... */

    int *sendcounts, *displs, sum = 0;
    sendcounts = (int *)malloc(num_procs*sizeof(int *));
    displs = (int *)malloc(num_procs*sizeof(int *));
    for (int i=0; i<num_procs; i++) {
        sendcounts[i] = n * m/num_procs + (i < m%num_procs) + (i != (num_procs-1));
        displs[i] = sum - (i != 0);
        sum += sendcounts[i];
    }
    
    my_image_chars = (unsigned char *)malloc(my_m*my_n*sizeof(unsigned char));

    MPI_Scatterv(&whole_image, sendcounts, displs, MPI_FLOAT, my_image_chars, sendcounts, MPI_FLOAT, 0, MPI_COMM_WORLD);
    
    
    if (my_rank==0) printf("Done!\nProceeding with converting...\n");
    convert_jpeg_to_image (my_image_chars, &u);
    
    if (my_rank==0) printf("Done!\nNow starting denoising");
    iso_diffusion_denoising_parallel (&u, &u_bar, kappa, iters);
    
    /* each process sends its resulting content of u_bar to process 0 */
    /* process 0 receives from each process incoming values and */
    /* copy them into the designated region of struct whole_image */
    /* ... */
    image u_complete;
    if (my_rank==0) {
        allocate_image(&u_complete, m, n);
    } else {
        u_complete.image_data = NULL;
    }

    MPI_Gatherv(&u_bar.image_data, sendcounts, MPI_FLOAT, &u_complete.image_data, sendcounts, displs, MPI_FLOAT, 0, MPI_COMM_WORLD);

    if (my_rank==0) {
        printf("\nDone!\nConverting back to jpeg format...\n");
        convert_image_to_jpeg(&whole_image, image_chars);
        printf("\n Done!\nCreating new file\n");
        export_JPEG_file(output_jpeg_filename, image_chars, m, n, c, 75);
        printf("Success! Cleaning up before exiting");
        deallocate_image (&whole_image);
    }
    deallocate_image(&u);
    deallocate_image(&u_bar);
    if (my_rank==0) deallocate_image(&u_complete);

    MPI_Finalize();
    return 0;
}